package com.library.management.models;

public class Member {

}
