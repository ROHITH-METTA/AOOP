package com.game;

public class Sword implements Weapon {
    @Override
    public void use() {
        System.out.println("Swinging the sword!");
    }
}
