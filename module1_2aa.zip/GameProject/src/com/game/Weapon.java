package com.game;

public interface Weapon {
    void use();
}
