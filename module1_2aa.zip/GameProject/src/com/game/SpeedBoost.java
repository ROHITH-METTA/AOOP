package com.game;

public class SpeedBoost implements PowerUp {
    @Override
    public void activate() {
        System.out.println("Speed boosted!");
    }
}
