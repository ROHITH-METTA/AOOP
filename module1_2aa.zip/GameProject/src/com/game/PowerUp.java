package com.game;

public interface PowerUp {
    void activate();
}
