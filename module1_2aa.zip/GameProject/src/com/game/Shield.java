package com.game;

public class Shield implements Weapon {
    @Override
    public void use() {
        System.out.println("Raising the shield!");
    }
}
