/**
 * 
 */
/**
 * 
 */
module AbstractFactoryPattern {
}