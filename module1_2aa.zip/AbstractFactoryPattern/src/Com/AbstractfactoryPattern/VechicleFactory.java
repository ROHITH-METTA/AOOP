package Com.AbstractfactoryPattern;

public  VehicleFavtory {


   car createcar() {
    // TODO Auto-generated method stub
   
  }


 bike createdikr() {
    // TODO Auto-generated method stub
   
  }

 
  
  }
  

}