package com.musicstreaming;

public interface MusicSource {
    void play();
    void pause();
    void stop();
}
