package com.musicstreaming;

public interface MusicPlayer {
    void play();
    void pause();
    void stop();
}
